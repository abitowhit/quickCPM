#!/usr/bin/python
# -*- coding: utf-8 -*-s
import os  # directory methods
import struct
import datetime
import time
import serial
import sys

gmc= serial.Serial('/dev/ttyUSB0', 115200, timeout= 3) #device
peak=0 #initial peak
slp=300 #interval 5min
def getWebPage(tval,cval):
    hpg = "<html><head><meta http-equiv=\"refresh\" content=\"30\"><meta http-equiv=\"Cache-Control\" content=\"no-store\" />"
    hpg += "<meta charset=\"UTF-8\"/><title>QuickCPM</title>"
    hpg += "<style>._PR {font-size:large;box-shadow: 3px 4px 5px #888888;color:#333;border-top-left-radius: 8px;border-top-right-radius: 8px;border-bottom-right-radius: 8px;border-bottom-left-radius: 8px;border-width:1px;border-style: solid;border-color:silver;text-align: left;margin:4px 4px 4px 4px;padding:4px 4px 4px 4px;}</style>"
    hpg += "</head><body style=\"background-color:silver;align-content:center\">GMC-320 Monitor"
    hpg += "<div style=\"width:96%;float:left;background-color:gray;align-content:center\" class=\"_PR\">"
    hpg += "<div class=\"_PR\" style=\"width:45%;float:left;background-color:#000000;color:#37bc2d\">Temp:<br><TMP></div>"
    hpg += "<div class=\"_PR\" style=\"width:45%;float:left;background-color:#000000;color:#37bc2d\"><CPM></div>"
    hpg += "</div></div></body></html>"
    
    return parsepage(tval,cval,hpg)

def parsepage(tval,cval,pval) :
    return (pval.replace("<TMP>",tval).replace("<CPM>",cval))

def getCPM(gmc): 
    gmc.write(b'<GETCPM>>')
    dat = gmc.read(2)
    try:
        gv= ord(dat[0])<< 8 | ord(dat[1])
    except IndexError:
        gv= ord("\x00")
    return gv

def writeToFile(fileName,data, isbinary, ishtml):
        if len(data)>1:
            fn= fileName # QtGui.QFileDialog.getSaveFileName(self, "Save file", "", "*.*")with open("test.txt", "a") as myfile:
            if isbinary:
                print "Writing binary"
                with open(fn, "wb") as file:  
                    file.write(data)  
                print "{:d} bytes saved to {:s}".format(len(data), fn)
            else:
                if ishtml:
                    with open(fn, "w") as file:  
                        file.write(data)
                        print "{:d} chars written to {:s}".format(len(data),fn)
                else:
                    with open(fn, "a") as file:  
                        file.write(data)
                        print "{:d} chars written to {:s}".format(len(data),fn)
                    
        else:
            print "No data to save"

        
def gmcCommand(gmc, cmd, returnlength, byteformat = True):
    try: #send command
        gmc.write(cmd)
    except:        
        print ("\nSend Error")#, sys.exc_info()
        gmc.close()
        sys.exit(1)
    try: #read data
        rtn = gmc.read(returnlength)
    except:
        print ("\nReceive ERROR")#, sys.exc_info()
        gmc.close()
        sys.exit(1)
    if byteformat: rtn = map(ord,rtn) # convert string to list of int
    return rtn

def getClock():
    clockval="<SETDATETIME[YYMMDDHHMMSS]>>"#set gmc clock cmd
    datenow = "{:%m/%d/%Y %H:%M:%S}".format(datetime.datetime.now())
    return datenow
def getFName(tagStr):
    fName = "logs/{:s}{:%Y%m%d}_{:s}.csv".format("gmc_",datetime.datetime.now(),tagStr)
    return fName
def tFile():
    fName = "logs/{:s}{:%Y%m%d}_temp.csv".format("gmc_",datetime.datetime.now())
    return fName
def getTEMP(gmc): 
    gmc.write(b'<GETTEMP>>')
    dat = gmc.read(4)
    try:
        i = ord(dat[0])# ord(dat[0])<< 8 | ord(dat[1])
        d = ord(dat[1])
        tCelcius = "{0}.{1}".format(i,d)
        tFarenheit=float(tCelcius)*1.4+32
        gv="{0},{1}".format(tCelcius,tFarenheit)
    except IndexError:
        gv  =ord("0")
    return gv

cl = getClock()
if len(sys.argv) > 1:
        print "Interval:{0} sec".format(sys.argv[1])# sys.argv[1:] = ["-h"]
        try:
            slp=float(sys.argv[1])
        except:
            print "Usage: python gmccpm.py 10 (for 10 sec interval)\nTimer argument [1] must be an integer"
            sys.exit(1)
try:
    while True:
        cl = getClock()
        currentCPM=getCPM(gmc)
        cpm = "{0},{1}\n".format(cl,currentCPM)
        if currentCPM > peak:
            peak=currentCPM
        print "{0} {1} (Peak:{2})".format(cl,currentCPM,peak)
        tmp = "{0}".format(getTEMP(gmc))
        tCel =tmp.split(',')[0]
        tF = tmp.split(',')[1]
        tCSV="{0},{1},{2}\n".format(cl,tF,tCel)
        tempDsply ="{0}c - {1}f".format(tCel,tF)
        tempH = "{:s}<table style=\"width:98%;bgcolor:white;height:14px;box-shadow:none;\">".format(tempDsply)
        tempH += "<td style=\"background-color:maroon;width:{0}%;border-top-left-radius: 8px;border-bottom-left-radius: 8px;padding:1px;margin-left:-8px;font-size:large;color:white;text-align:center\"><b>{0}f </b></td>".format(tmp.split(',')[1])
        tempH += "<td style=\"background-color:#eaeaea;padding:1px;border-top-right-radius: 8px;border-bottom-right-radius: 8px\"></td></table><br>"
        pkH = "<table style=\"width:98%;bgcolor:white;height:14px;box-shadow:none;\">"
        pkH += "<td style=\"background-color:darkblue;width:{0}%;border-top-left-radius: 8px;border-bottom-left-radius: 8px;padding:1px;margin-left:-8px;font-size:small;color:white;text-align:center\"><b>{0} CPM </b></td>".format(peak)
        pkH += "<td style=\"background-color:#eaeaea;padding:1px;border-top-right-radius: 8px;border-bottom-right-radius: 8px\"></td></table>"
        print tempDsply
        cpmH = "{0}<br>Peak: {1}".format(cpm.replace(' ','-').replace(',',"<br>CPM: "),peak)
        cpmH += pkH
        writeToFile(getFName("cpm"),cpm,0,0)
        writeToFile(getFName("temp"),tCSV,0,0)
        writeToFile("index.html",getWebPage(tempH,cpmH),0,1)
        time.sleep(slp) 
except KeyboardInterrupt:
    pass
