import os
os.chdir(r"/home/pi/bin/quickcpm")
with open("gauge.min.js",'r') as f:
    rd = f.read().replace(";",";\n")
    f.close()
g=open('gauge.min.js','w')
g.write(rd)
g.close()
    
    
    
    
